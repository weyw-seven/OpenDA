import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.decomposition import PCA
from dataset import Dataset
import time

# 构建数据集
data = Dataset("../celeba")
X_imgs_train, X_attrs_train, Y_train, X_landmark_train = data.get_train_data()
X_imgs_test, X_attrs_test, Y_test, X_landmark_test  = data.get_test_data()

# 选择属性特征作为分类依据
# X_train = X_attrs_train
# X_test = X_attrs_test

# TODO: 选择原始图片作为分类依据
# 提示: 单张图片的原始形状是[H, W, 3]，需将其转换成一维特征再利用SVM分类
'''
    请补全相关代码
'''
# 将图像展平
X_train_img_flat = X_imgs_train.reshape(X_imgs_train.shape[0], -1)
X_test_img_flat = X_imgs_test.reshape(X_imgs_test.shape[0], -1)
# 使用主成分提取对图像数据降维
pca = PCA(n_components=240)
X_train_img_pca = pca.fit_transform(X_train_img_flat)
X_test_img_pca = pca.transform(X_test_img_flat)
# 将图像特征、属性特征合并
X_train_combined = np.hstack((X_train_img_pca, X_attrs_train))
X_test_combined = np.hstack((X_test_img_pca, X_attrs_test))
# X_train_combined = np.hstack((X_train_combined,X_landmark_train))
# X_test_combined = np.hstack((X_test_combined,X_landmark_test))
# 标准化训练集和测试集
sc = StandardScaler()               # 定义一个标准缩放器
X_train_std = sc.fit_transform(X_train_combined) # 使用计算出的均值和标准差进行标准化
X_test_std  = sc.transform(X_test_combined)  # 使用计算出的均值和标准差进行标准化


# TODO: 训练支持向量机
# 提示: 
'''
    请补全下方对SVC模型的定义, 包括核函数、软间隔惩罚项的系数等
'''
for c in [0.1, 1, 10, 100, 1000, 10000]:
    for kernel in ['linear', 'poly', 'rbf', 'sigmoid']:
        gamma = 'auto'
        starttime = time.time()
        svm = SVC(kernel= kernel, C=c,gamma=gamma)      # 定义线性支持向量分类器 (linear为线性核函数)
        svm.fit(X_train_std, Y_train)       # 根据给定的训练数据拟合训练SVM模型

        # 使用测试集进行数据预测
        Y_pred = svm.predict(X_test_std)    # 用训练好的分类器svm预测数据X_test_std的标签
        print('Misclassified samples: %d' % (Y_test != Y_pred).sum())   # 输出错误分类的样本数
        acc = svm.score(X_test_std, Y_test)
        print('Accuracy: %.2f' % acc)         # 输出分类准确率

        endtime = time.time()
        print('Time: %.2f' % ((endtime-starttime)*1000))

        with open('svm.csv', 'a') as f:
            f.write(f"{c},{kernel},{gamma},{acc}\n")

