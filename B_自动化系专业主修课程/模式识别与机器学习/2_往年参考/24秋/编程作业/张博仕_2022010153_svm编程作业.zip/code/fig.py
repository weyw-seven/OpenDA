import matplotlib.pyplot as plt
C_values = [0.1, 1, 10, 100, 1000, 10000]
linear_acc = [0.96, 0.96, 0.96, 0.96, 0.96, 0.96]
rbf_acc = [0.90, 0.94, 0.92, 0.92, 0.92, 0.92]
sigmoid_acc = [0.96, 0.96, 0.98, 0.98, 0.98, 0.98]
plt.figure(figsize=(8, 6))
plt.plot(C_values, linear_acc, marker='o', label='Linear')
plt.plot(C_values, rbf_acc, marker='s', label='RBF')
plt.plot(C_values, sigmoid_acc, marker='^', label='Sigmoid')
plt.xscale('log')
plt.xlabel('C')
plt.ylabel('Accuracy')
plt.title('Comparison of SVM Kernels (Linear, RBF, Sigmoid) with Different C Values')
plt.legend()
plt.grid(True)
plt.show()