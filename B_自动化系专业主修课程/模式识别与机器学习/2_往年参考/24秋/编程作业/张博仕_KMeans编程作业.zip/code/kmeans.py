import numpy as np
from dataset import Dataset

class KMeans:

    def __init__(self, x, num_clusters):
        self.img_shape = x.shape[1:]
        self.num_samples = x.shape[0]
        x = x.reshape((self.num_samples, -1))
        self.x = x
        self.dimension = x.shape[1]
        self.num_cluster = num_clusters
        self.reset_params()
    
    def reset_params(self):
        self.mu = self.x[np.random.choice(self.num_samples, self.num_cluster, False)]
        self.cls = np.zeros((self.num_samples, ), dtype=np.int32)
        
    def assign_cluster(self):
        ## TODO 1: Update self.cls 
        dis = np.zeros((self.num_samples, self.num_cluster)) 
        for i in range(self.num_samples):
            for j in range(self.num_cluster):
                dis[i, j] = np.sqrt(np.sum((self.x[i] - self.mu[j]) ** 2)) 

        for i in range(self.num_samples):
            self.cls[i] = np.argmin(dis[i])

    def update_cluster(self):
        ## TODO 2: Update self.mu
        for i in range(self.num_cluster):
            cluster_points = [] 
            for j in range(self.num_samples):
                if self.cls[j] == i:
                    cluster_points.append(self.x[j])
            #如果簇过多，有的簇可能没有点，这时候不更新这个簇的中心
            if len(cluster_points) > 0:
                n_center = np.zeros(self.dimension)
                for point in cluster_points:
                    n_center += point
                n_center /= len(cluster_points)
                self.mu[i] = n_center

    def fit(self, max_iter=200):
        self.reset_params()
        for _ in range(max_iter):
            self.assign_cluster()
            self.update_cluster()
        self.assign_cluster()

    def assign_label(self, ids):
        cluster_ids = {}
        for i in range(self.num_cluster):
            ## TODO 3: Determine the id for the ith cluster by majority voting
            cluster_points = [ids[j] for j in range(self.num_samples) if self.cls[j] == i]
            if len(cluster_points) > 0:
                label_count = {}
                for label in cluster_points:
                    if label not in label_count:
                        label_count[label] = 0
                    label_count[label] += 1
                majority_label = max(label_count, key=label_count.get)
                cluster_ids[i] = majority_label
            else:
                #假如有的簇没有点，那么这个簇的id定义为-1
                cluster_ids[i] = -1 
        self.cluster_ids = cluster_ids
    
    def predict(self, datas, ids):
        distance = datas[:, None, :] - self.mu[None, :, :]
        distance = np.linalg.norm(distance, 2, -1)
        cls = np.argmin(distance, -1)

        pred_ids = [self.cluster_ids[i] for i in cls]
        correct = [pred_id == id for pred_id, id in zip(pred_ids, ids)]
        correct = np.array(correct)
        accuracy = np.sum(correct) / len(correct)

        return accuracy


def project(projection_matrix, data):
    data = np.dot(projection_matrix, np.transpose(
        data.reshape(data.shape[0], -1)))
    data = np.transpose(data)
    return data


if __name__ == "__main__":

    np.random.seed(42)

    data = Dataset('../celeba', 0.2, False, True)
    train_imgs = data.get_train_imgs()
    train_ids = data.get_train_ids()
    test_imgs = data.get_test_imgs()
    test_ids = data.get_test_ids()

    ## do dimension reduction
    # NOTE that this projection_matrix can be derived from dimension reduction,
    # Leave it alone for now.
    projection_matrix = np.load('projection_matrix.npy')
    train_feats = project(projection_matrix, train_imgs)
    test_feats = project(projection_matrix, test_imgs)
    # 在main函数中，检查train_feats和train_ids的样本
    print("Train samples: ", train_feats[:5])
    print("Train labels: ", train_ids[:5])
    acc = []
    for i in range(5, 255,5):
        
        kmeans = KMeans(train_feats, i)
        kmeans.fit(3)
        kmeans.assign_label(train_ids)
        tacc = kmeans.predict(train_feats, train_ids)
        testacc = kmeans.predict(test_feats, test_ids)
        print('train accuracy: ', tacc)
        print('test accuracy: ', testacc)
        acc.append ({"clusters":i,"train accuracy":tacc,"test accuracy":testacc})
    
    with open('kmeans.csv', 'w') as f: 
        f.write('clusters,train accuracy,test accuracy\n')
        for i in acc:
            f.write(f"{i['clusters']},{i['train accuracy']},{i['test accuracy']}\n")
    
