import os
import PIL.Image as Image
import numpy as np

class Dataset:

    def __init__(self, datapath, downsample_rate=1.0, gray=False, crop=False):
        self.datapath = datapath
        self.downsample_rate = downsample_rate
        self.gray = gray
        self.crop = crop

        with open(os.path.join(datapath, 'celeba_filtered.txt'), 'r') as f:
            id_filename_attribute = f.readlines()
        self.attributeNames = id_filename_attribute[0].split()[2:]
        ids, filenames, attributes = [], [], []
        for item in id_filename_attribute[1:]:
            item_split = item.split()
            ids.append(item_split[0])
            filenames.append(item_split[1])
            attributes.append([int(attr) for attr in item_split[2:]])
        self.ids = ids
        self.filenames = filenames
        self.attributes = attributes

        with open(os.path.join(datapath, 'celeba_landmarks.txt'), 'r') as f:
            filename_landmarks = f.readlines()
        self.landmark_names = filename_landmarks[0].split()[1:]
        landmarks = []
        for i, item in enumerate(filename_landmarks[1:]):
            item_split = item.split()
            assert item_split[0] == self.filenames[i]
            landmarks.append(item_split[1:])
        self.landmarks = landmarks
        
        with open(os.path.join(datapath, 'partition.txt'), 'r') as f:
            partitions = f.readlines()
        train_indices, test_indices = [], []
        for i, item in enumerate(partitions):
            item_split = item.split()
            assert item_split[0] == self.filenames[i]
            if item_split[1] == '0':
                train_indices.append(i)
            elif item_split[1] == '1':
                test_indices.append(i)
            else:
                raise ValueError
        self.train_indices = train_indices
        self.test_indices = test_indices

    def get_imgs(self, indices):
        imgs = []
        for index in indices:
            img = Image.open(os.path.join(
                self.datapath, 'celeba_filtered', self.filenames[index]))
            if self.gray:
                img = img.convert('L')
            if self.crop:
                original_size = img.size
                img = img.crop([48, 71, 128, 192])
                img = img.resize(original_size)
                # img.save(os.path.join(self.datapath, 'celeba_filtered_cropped', self.filenames[index]))
            if self.downsample_rate != 0:
                img = img.resize([int(s * self.downsample_rate) for s in img.size])

            img = np.asarray(img)
            imgs.append(img)
        imgs = np.stack(imgs, axis=0)
        imgs = imgs.astype(np.float32) / 128. - 1.
        return imgs
    
    def get_ids(self, indices):
        return np.array([self.ids[index] for index in indices])
    
    def get_train_imgs(self):
        return self.get_imgs(self.train_indices)
    
    def get_train_ids(self):
        return self.get_ids(self.train_indices)
        
    def get_test_imgs(self):
        return self.get_imgs(self.test_indices)     

    def get_test_ids(self):
        return self.get_ids(self.test_indices)

    
if __name__ == "__main__":

    ## test dataset
    data = Dataset("../celeba")
    train_imgs = data.get_train_imgs()
    test_imgs = data.get_test_imgs()

    breakpoint()