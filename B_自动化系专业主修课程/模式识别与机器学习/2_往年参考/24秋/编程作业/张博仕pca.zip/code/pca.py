import numpy as np
import matplotlib.pyplot as plt
from dataset import Dataset

class PCA(object):
    """PCA Class"""
    def __init__(self, x, n_components=None):
        self.img_shape = x.shape[1:]
        x = x.reshape((x.shape[0], -1))
        self.x = x
        self.dimension = x.shape[1]
        if n_components and n_components >= self.dimension:
            raise ValueError("n_components error")
        self.n_components = n_components
        
    def cov(self, x):
        # TODO 1
        x_mean = np.mean(x, axis=0, keepdims=True)
        x_c = x - x_mean
        return np.dot(x_c.T, x_c) 

    def eigen_decompose(self, cov_matrix):
        # TODO 2
        eigen_values, eigen_vectors = np.linalg.eig(cov_matrix)
        return eigen_values, eigen_vectors.T#np.linalg.eig返回的序号在第二维所以转置一下
    
                
    def draw_eigen_values(self, eigen_values):
        plt.cla(); plt.clf()
        plt.plot(eigen_values, 'k')
        plt.xlabel('n_components', fontsize=16)
        plt.ylabel('eigen_values', fontsize=16)
        plt.savefig('pca_eigen_values.png')
        plt.close()
    
    def draw_eigen_faces(self, average_face, eigen_faces,d=8):
        average_face = (average_face - average_face.min()) / (average_face.max() - average_face.min())
        eigen_faces = (eigen_faces - eigen_faces.min()) / (eigen_faces.max() - eigen_faces.min())
  

        plt.cla(); plt.clf()
        plt.figure(figsize=(15, 6))
        plt.subplot(4, 10, 1)
        plt.imshow(average_face)
        plt.axis('off')
        for i in range(min(len(eigen_faces), 30)): 
            row = (i // 10) + 1  
            col = i % 10 + 1  
            plt.subplot(4, 10, row * 10 + col) 
            plt.imshow(eigen_faces[i])
            plt.axis('off')
        plt.savefig(f'pca_eigen_faces_{d}.png')
        plt.close()

    def draw_original_and_reconstruct(self, input, recon,d):
        recon = (recon - input.min()) / (input.max() - input.min())
        input = (input - input.min()) / (input.max() - input.min())
        recon = np.clip(recon, 0, 1)
        input = np.clip(input, 0, 1)

        plt.cla(); plt.clf()
        plt.figure(figsize=(10, 2))
        for i in range(10):
            plt.subplot(2, 10, i + 1)
            plt.imshow(input[i])
            plt.axis('off')
            plt.subplot(2, 10, 10 + i + 1)
            plt.imshow(recon[i])
            plt.axis('off')
        plt.savefig(f'pca_input_recon_{d}.png')

        plt.close()
              
    def reduce_dimension(self,d):
        ## N: Number of samples, D: Original dimension, d: reduced dimension

        ## TODO 1: calculate covariance matrix
        # cov_matrix: D, D
        cov_matrix = self.cov(self.x) 

        ## TODO 2: calculate the eigen values and vectors of the covariance matrix
        # eigen_values: D; eigen_vectors: D, D (every row is an eigen vector)
        eigen_values, eigen_vectors = self.eigen_decompose(cov_matrix)

        ## TODO 3: sort the eigen_values and reorder the eigen vectors accordingly
        sorted_indices = np.argsort(eigen_values)[::-1]
        eigen_values = eigen_values[sorted_indices]
        eigen_vectors = eigen_vectors[sorted_indices]

        ## TODO 4: do projection and finish dimension reduction
        # project_matrix: d,D; result: N, d
        project_matrix = eigen_vectors[:self.n_components]
        self.project_matrix = project_matrix
        result = np.dot(self.x, project_matrix.T)

        ## draw the average face and eigen faces
        # plot all the eigen values in descending order
        self.draw_eigen_values(eigen_values=eigen_values)
        average_face = self.x.mean(axis=0).reshape(self.img_shape)
        eigen_faces = eigen_vectors[:self.n_components]
        eigen_faces = eigen_faces.reshape((self.n_components, *self.img_shape))  

        self.draw_eigen_faces(average_face=average_face, eigen_faces=eigen_faces,d=d)

        return result

    def project_and_reconstruct(self, data, d):
        data = data.reshape((data.shape[0], -1))
        result = np.dot(self.project_matrix, np.transpose(data))
        result = np.transpose(result)

        reconstruct = np.dot(result, self.project_matrix)
        self.draw_original_and_reconstruct(
            data.reshape(data.shape[0], *self.img_shape),
            reconstruct.reshape(reconstruct.shape[0], *self.img_shape)
            ,d=d)
        return result, reconstruct
    

if __name__ == '__main__':

    data = Dataset('../celeba', 0.2, False, True)
    train_imgs = data.get_train_imgs()
    test_imgs = data.get_test_imgs()
    for d in [64]:
        pca = PCA(train_imgs, d)
        result = pca.reduce_dimension(d=d)
        input, recon = pca.project_and_reconstruct(test_imgs, d)

